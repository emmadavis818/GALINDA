# CodeAstro-Group11
Group 11's PyPI Package, CodeAstro 2025

GALINDA is a Galaxy Image N-Body Data Animator
